import pandas as pd
import google.generativeai as genai
def generator():
    # STEP 1: Load sprint story data
    df = pd.read_csv("SCRUM-1_Sprint_Report.csv")  # path to your actual file

    # STEP 2: Format into a textual summary for Gemini
    def build_prompt_from_dataframe(df):
        stories_text = ""
        for _, row in df.iterrows():
            stories_text += (
                f"- Title: {row['Story Title']}\n"
                f"  Assignee: {row['Assignee']}\n"
                f"  Status: {row['Status']}\n"
                f"  Comments: {row['Comments']}\n\n"
            )
        prompt = f"""You are a software engineering team assistant. Below is a list of Jira stories from a completed sprint.

    Each story includes a title, assignee, status, and developer comment.

    Generate a retrospective report based on this information. The report should include:
    1. What went well
    2. What didn’t go well
    3. Suggested improvements or action items

    Be concise, insightful, and professional.

    Here is the list of stories:
    {stories_text}

    Now generate the retrospective:
    """
        return prompt

    # STEP 3: Connect to Gemini and get response
    genai.configure(api_key="AIzaSyA9ooGbdpsito31zLqvhX1ORnffrH1uc60")  # Replace with your API key

    model = genai.GenerativeModel("gemini-2.0-flash")

    prompt = build_prompt_from_dataframe(df)
    response = model.generate_content(prompt)

    # STEP 4: Print or save result
    print(response.text)
    with open("SCRUM-1_Retrospective.txt", "w") as f:
        f.write(response.text)
