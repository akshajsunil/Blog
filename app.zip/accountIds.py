import requests
from requests.auth import HTTPBasicAuth

# --------- CONFIG ---------
JIRA_DOMAIN = "akshajsket2.atlassian.net"
EMAIL = "akshajsket2@gmail.com"
API_TOKEN = "ATATT3xFfGF0u3-Y6FK_jmb1A04BxMC6hbCTzDSR0lC2iCP4VJQ3ZPPSK6yrR6MM3nhAadj7N4Egj3Dw9aiwTUMg5O5w_YCRtmUOkmtiQ9tBwneAWGaMBRCy7IUn32pE1ZjifN5vB1JzY7DH7PAyaPpgZ1c9I6MZ7EJyW7bjMz73xGIxam6yEy8=3C048A44"

auth = HTTPBasicAuth(EMAIL, API_TOKEN)
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}

# --------- GET USERS ---------
url = "https://akshajsket2.atlassian.net/rest/api/3/users/search"

response = requests.get(url, headers=headers, auth=auth)

if response.status_code == 200:
    users = response.json()
    print("Users in your Jira site:\n")
    for user in users:
        print(f"Display Name: {user['displayName']}")
        print(f"Email: {user.get('emailAddress', 'N/A')}")
        print(f"Account ID: {user['accountId']}\n")
else:
    print(f"Failed to fetch users: {response.status_code}")
    print(response.text)
