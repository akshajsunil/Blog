import streamlit as st
import subprocess
import os
from boardToExcel import getData
from Generator import generator
# --- Streamlit UI ---

st.set_page_config(page_title="Jira Retrospective Report Generator", layout="centered")

st.title("Jira Retrospective Report Generator")

st.write(
    "Enter a Jira sprint board link. This app will use your existing scripts "
    "to generate a CSV sprint report and then a retrospective report, "
    "which will be displayed here and available for download."
)

jira_url = st.text_input(
    "Jira Board URL:",
    placeholder="e.g., https://your-jira.atlassian.net/rest/agile/1.0/board/{BOARD_ID}/sprint/{SPRINT_ID}"
)

# Optional: Add a text input for the output filename if generator.py is flexible
# For now, we assume generator.py outputs to SCRUM-1_Retrospective.txt
output_report_filename = "SCRUM-1_Retrospective.txt"
output_csv_filename = "sprint_report.csv" # Assuming boardToExcel.py outputs this

if st.button("Generate Retrospective Report"):
    if not jira_url:
        st.error("Please enter a Jira board URL.")
    else:
        # Step 1: Run boardToExcel.py to get the CSV
        st.info(f"Running boardToExcel.py with URL: {jira_url}...")
        try:
            # Assuming boardToExcel.py takes the URL as a command-line argument
            # and outputs to a file named 'sprint_report.csv'
            # If your script has a different input/output mechanism, adjust this.
            getData(jira_url)
            st.success(f"Successfully generated {output_csv_filename}.")
            
            # Step 2: Run generator.py to create the retrospective report
            st.info(f"Running generator.py to create {output_report_filename}...")
            # Assuming generator.py just runs and creates the file in the same directory
            generator()
            st.success(f"Successfully generated {output_report_filename}.")

            # Step 3: Read and display the report content
            if os.path.exists(output_report_filename):
                with open(output_report_filename, "r", encoding="utf-8") as f:
                    report_content = f.read()

                st.subheader("Generated Retrospective Report:")
                st.markdown(report_content)

                # Provide download button
                st.download_button(
                    label="Download Retrospective Report",
                    data=report_content,
                    file_name=output_report_filename,
                    mime="text/plain"
                )
            else:
                st.error(f"Could not find the generated report file: {output_report_filename}. "
                         "Please ensure generator.py creates this file.")

        except subprocess.CalledProcessError as e:
            st.error(f"An error occurred while running your scripts. "
                     f"**Command:** {' '.join(e.cmd)}\n"
                     f"**Return Code:** {e.returncode}\n"
                     f"**STDOUT:**\n```\n{e.stdout.decode()}\n```\n"
                     f"**STDERR:**\n```\n{e.stderr.decode()}\n```\n"
                     "Please check your `boardToExcel.py` and `generator.py` scripts for errors.")
        except FileNotFoundError:
            st.error("One of your scripts (e.g., `boardToExcel.py` or `generator.py`) was not found. "
                     "Make sure they are in the same directory as this Streamlit app.")
        except Exception as e:
            st.error(f"An unexpected error occurred: {e}")

st.markdown("---")
st.markdown("Developed with ❤️ using Streamlit")