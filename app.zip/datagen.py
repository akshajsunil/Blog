import requests
from requests.auth import HTTPBasicAuth

# --------- CONFIG ---------
JIRA_DOMAIN = "akshajsket2.atlassian.net"
EMAIL = "akshajsket2@gmail.com"
API_TOKEN = "ATATT3xFfGF0u3-Y6FK_jmb1A04BxMC6hbCTzDSR0lC2iCP4VJQ3ZPPSK6yrR6MM3nhAadj7N4Egj3Dw9aiwTUMg5O5w_YCRtmUOkmtiQ9tBwneAWGaMBRCy7IUn32pE1ZjifN5vB1JzY7DH7PAyaPpgZ1c9I6MZ7EJyW7bjMz73xGIxam6yEy8=3C048A44"
PROJECT_KEY = "SCRUM"

# Replace with actual Jira account IDs (not emails!)
developers = {
    "Alice": "712020:f1e68dd0-44b7-43ef-99b8-faa1c4249250",
    "Bob": "712020:eb441b0c-9216-4cc7-be80-f9255ab83e0e",
    "Charlie": "712020:28e9d015-ba97-4170-a658-75061974af15"
}

issues = [
    {
        "summary": "Implement Login and Onboarding UI",
        "assignee": "Alice",
        "comment": "Completed integration with the new component library. Minor styling tweaks pending from UX feedback."
    },
    {
        "summary": "Build Coach Booking API",
        "assignee": "Bob",
        "comment": "Initial implementation had latency issues due to N+1 queries. Refactored with optimized joins."
    },
    {
        "summary": "Setup CI/CD Pipeline for Dev",
        "assignee": "Charlie",
        "comment": "Enabled auto-deploy to dev on PR merge. Faced an hour of downtime due to misconfigured secrets."
    },
    {
        "summary": "Create Profile Page with Editable Form",
        "assignee": "Alice",
        "comment": "Added reusable form logic. Some issues with form validation library on Safari, patched quickly."
    },
    {
        "summary": "Store Booking History in Database",
        "assignee": "Bob",
        "comment": "Initial PR raised. Need clarification on schema from Analytics team."
    },
    {
        "summary": "Write Automated Regression Tests",
        "assignee": "Charlie",
        "comment": "Covered 75% of UI flows. Missed DB fallback cases due to missing test data."
    },
    {
        "summary": "Investigate Intermittent API Timeouts",
        "assignee": "Bob",
        "comment": "Timeouts traced to unindexed column. Indexed and reduced p95 latency from 900ms → 250ms."
    },
    {
        "summary": "Create Test Data Management Checklist",
        "assignee": "Charlie",
        "comment": "Drafted a checklist shared in Confluence. Added 'auth token age' edge case."
    }
]

auth = HTTPBasicAuth(EMAIL, API_TOKEN)
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}

def create_issue(summary, assignee_account_id):
    url = f"https://{JIRA_DOMAIN}/rest/api/3/issue"
    payload = {
        "fields": {
            "project": {"key": PROJECT_KEY},
            "summary": summary,
            "description": {
                "type": "doc",
                "version": 1,
                "content": [
                    {
                        "type": "paragraph",
                        "content": [
                            {
                                "type": "text",
                                "text": summary
                            }
                        ]
                    }
                ]
            },
            "issuetype": {"name": "Task"},
            "assignee": {"accountId": assignee_account_id}
        }
    }
    response = requests.post(url, json=payload, headers=headers, auth=auth)
    if response.status_code == 201:
        issue_key = response.json()['key']
        print(f"Issue {issue_key} created: {summary}")
        return issue_key
    else:
        print(f"Failed to create issue '{summary}': {response.text}")
        return None

def add_comment(issue_key, comment):
    url = f"https://{JIRA_DOMAIN}/rest/api/3/issue/{issue_key}/comment"
    payload = {
        "body": {
            "type": "doc",
            "version": 1,
            "content": [
                {
                    "type": "paragraph",
                    "content": [
                        {
                            "type": "text",
                            "text": comment
                        }
                    ]
                }
            ]
        }
    }
    response = requests.post(url, json=payload, headers=headers, auth=auth)
    if response.status_code == 201:
        print(f"Added comment to {issue_key}")
    else:
        print(f"Failed to add comment to {issue_key}: {response.text}")

def main():
    created_issues = []
    for issue in issues:
        assignee_id = developers.get(issue['assignee'])
        if not assignee_id:
            print(f"Account ID for {issue['assignee']} not found. Skipping issue '{issue['summary']}'.")
            continue

        key = create_issue(issue['summary'], assignee_id)
        if key:
            add_comment(key, issue['comment'])
            created_issues.append(key)

    print(f"\nCreated {len(created_issues)} issues with comments.")

if __name__ == "__main__":
    main()
