import requests
from requests.auth import HTTPBasicAuth
import pandas as pd
def getData(sprints_url):
    # --------- CONFIG ---------
    JIRA_DOMAIN = "akshajsket2.atlassian.net"
    EMAIL = "akshajsket2@gmail.com"
    API_TOKEN = "ATATT3xFfGF0u3-Y6FK_jmb1A04BxMC6hbCTzDSR0lC2iCP4VJQ3ZPPSK6yrR6MM3nhAadj7N4Egj3Dw9aiwTUMg5O5w_YCRtmUOkmtiQ9tBwneAWGaMBRCy7IUn32pE1ZjifN5vB1JzY7DH7PAyaPpgZ1c9I6MZ7EJyW7bjMz73xGIxam6yEy8=3C048A44"
    BOARD_ID = 1  # Replace this if your board has a different ID
    SPRINT_NAME = "SCRUM Sprint 1"  # Sprint name to look for
    #https://akshajsket2.atlassian.net/rest/agile/1.0/board/1/sprint
    auth = HTTPBasicAuth(EMAIL, API_TOKEN)
    headers = {
        "Accept": "application/json"
    }

    # --------- 1. Get all sprints ---------
    if(not sprints_url):
        sprints_url = f"https://{JIRA_DOMAIN}/rest/agile/1.0/board/{BOARD_ID}/sprint"
    sprints = requests.get(sprints_url, headers=headers, auth=auth).json()

    sprint_id = None
    for sprint in sprints.get("values", []):
        if sprint["name"] == SPRINT_NAME:
            sprint_id = sprint["id"]
            break

    if not sprint_id:
        print(f"Sprint '{SPRINT_NAME}' not found.")
        exit()

    # --------- 2. Get issues in the sprint ---------
    issues_url = f"https://{JIRA_DOMAIN}/rest/agile/1.0/sprint/{sprint_id}/issue?maxResults=100"
    issues = requests.get(issues_url, headers=headers, auth=auth).json().get("issues", [])

    # --------- 3. Process issue data ---------
    data = []

    for issue in issues:
        key = issue["key"]
        fields = issue["fields"]

        title = fields["summary"]
        status = fields["status"]["name"]
        assignee = fields["assignee"]["displayName"] if fields["assignee"] else "Unassigned"

        # Get comments
        comments_url = f"https://{JIRA_DOMAIN}/rest/api/3/issue/{key}/comment"
        comments_resp = requests.get(comments_url, headers=headers, auth=auth).json()
        comments = "\n---\n".join([c["body"]["content"][0]["content"][0]["text"] 
                                    for c in comments_resp.get("comments", []) 
                                    if c["body"]["type"] == "doc" and c["body"]["content"]])

        data.append({
            "Story Title": title,
            "Assignee": assignee,
            "Status": status,
            "Comments": comments
        })

    # --------- 4. Export to Excel ---------
    df = pd.DataFrame(data)
    df.to_csv("SCRUM-1_Sprint_Report.csv", index=False)

    print("✅ Excel file 'SCRUM-1_Sprint_Report.xlsx' created successfully.")
